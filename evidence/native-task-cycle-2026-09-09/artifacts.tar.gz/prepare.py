import pathlib,json,subprocess,sys,hashlib,datetime
root=pathlib.Path(__file__).resolve().parent
project=pathlib.Path('/Users/marcus.kim/repositories/individual/agent-learning-workflow')
node='/Users/marcus.kim/.nvm/versions/node/v24.15.0/bin/node'
lyo='/Users/marcus.kim/.nvm/versions/node/v24.15.0/bin/lyo'
cases={
 'cost':'In src/eval/report.ts, paired success gains currently allow promotion even when total treatment token cost exceeds baseline. Prevent promotion when measured treatment tokens exceed baseline, including a zero-token baseline. Preserve successful equal-cost or cheaper interventions and all existing evidence/regression guards.',
 'command':'The eval task reader accepts whitespace-only success_check.command values, allowing a shell no-op to count as verification. Reject these invalid commands while preserving valid task data. Fix the shared validation boundary and add a focused regression test.',
 'identity':'The eval task reader accepts whitespace-only task_id, prompt, and repo_ref.ref strings. Reject blank required textual fields at the shared validation boundary while preserving valid content. Add a focused regression test.',
 'arrays':'The eval task reader accepts whitespace-only elements in allowed_tools, expected_touched_paths, and tags. Reject blank array elements at the shared validation boundary while preserving valid task data. Add a focused regression test.',
 'metadata':'In src/eval/report.ts, promotion can currently be accepted when model or harness identity is empty, whitespace-only, or exactly the sentinel unknown. Prevent promotion for these missing identities (invalid input or inconclusive is acceptable), while preserving real names such as unknown-model-family and existing valid comparisons. Add a focused regression test.',
 'budget-order':'In src/eval/report.ts, equivalent budget objects with different JSON property insertion order are treated as incomparable. Compare budget values independently of object key order, while preserving the rejection of genuinely different budgets and all other comparison guards. Add a focused regression test.'}
scenario,condition,ident=sys.argv[1:4]
cwd=root/ident
if not cwd.exists(): subprocess.run(['git','worktree','add','--detach',str(cwd),'v0.4.2'],cwd=project,check=True,stdout=subprocess.DEVNULL)
(cwd/'node_modules').symlink_to(project/'.worktrees/feat/native-feedback-cycle/node_modules',target_is_directory=True) if not (cwd/'node_modules').exists() else None
gate=cwd/'.opcore/hooks/opcore-agent-gate.mjs';gate.parent.mkdir(parents=True,exist_ok=True)
subprocess.run([node,'--input-type=module','-e',"import {opcoreAgentGateHookScriptContent} from 'file:///Users/marcus.kim/.nvm/versions/node/v24.15.0/lib/node_modules/opcore/dist/agent-gate.js'; process.stdout.write(opcoreAgentGateHookScriptContent());"],stdout=gate.open('w'),check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=cwd,text=True).strip()
prompt=cases[scenario]+'\nThis is an isolated experimental worktree already prepared for this ticket. Edit this checkout in place. Do not create another worktree, commit, change configuration, or delegate. Keep the fix scoped; use TDD and the relevant existing tests. Prefix shell commands with rtk. Do not read outside this checkout for task solutions or inspect the external pilot verifier. Report what changed and how you checked it.'
v=str(root/'verify.mjs')
r={'attemptId':'pilot-20260909-'+ident,'cwd':str(cwd),'runtime':'codex','model':'gpt-6-astra','family':'lyo-eval-validation-pilot-20260909',
 'condition':condition,'criteria':[cases[scenario]],'verifierFiles':[v],'regressionCheck':{'command':f'{node} {v} regression {scenario}','files':[v]},
 'task':{'task_id':scenario,'split':'train' if condition=='explore' else 'selection','repo_ref':{'kind':'git','ref':head},
 'prompt':prompt,'allowed_tools':['shell','edit'],'budget':{'max_turns':10,'max_wall_time_seconds':480,'max_tokens':500000},
 'success_check':{'kind':'command','command':f'{node} {v} acceptance {scenario}'},
 'expected_touched_paths':['src/eval/tasks.ts' if scenario in ['command','identity','arrays'] else 'src/eval/report.ts'],'tags':['validation-pilot']}}
if condition!='explore': r['pairId']='pilot-20260909-'+scenario
if condition=='learned':r['policyId']=json.loads((root/'policy.json').read_text())['policy']['id']
(root/(ident+'.registration.json')).write_text(json.dumps(r,indent=2))
checks={}
for phase in ['regression','acceptance']:
 p=subprocess.run([node,v,phase,scenario],cwd=cwd,text=True,capture_output=True)
 checks[phase]={'exitCode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
(root/(ident+'.before.json')).write_text(json.dumps(checks,indent=2))
assert checks['regression']['exitCode']==0,checks
assert checks['acceptance']['exitCode']!=0,'task was already solved at baseline'
print(json.dumps({'attempt':r['attemptId'],'cwd':str(cwd),'regression':0,'acceptance':'fails before work'}))
