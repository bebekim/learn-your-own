import json,pathlib,subprocess,datetime
root=pathlib.Path(__file__).resolve().parent
node='/Users/marcus.kim/.nvm/versions/node/v24.15.0/bin/node'
lyo='/Users/marcus.kim/.nvm/versions/node/v24.15.0/bin/lyo'
db='/Users/marcus.kim/.lyo/corpus.sqlite'
policy=json.loads((root/'policy.json').read_text())['policy']['id']
names=['metadata-baseline','metadata-learned','budget-order-learned','budget-order-baseline']
def command(args,path):
    with (root/path).open('w') as out: subprocess.run([node,lyo,'task',*args,'--db',db],stdout=out,check=True)
for name in names: command(['register','--input',str(root/(name+'.registration.json'))],name+'.registered.json')
comparison={'id':'pilot-20260909-transfer','policyId':policy,'pairs':[{'baselineAttemptId':'pilot-20260909-'+case+'-baseline','learnedAttemptId':'pilot-20260909-'+case+'-learned'} for case in ['metadata','budget-order']],'maxTotalTokenRatio':1}
(root/'comparison.json').write_text(json.dumps(comparison,indent=2))
command(['compare','--input',str(root/'comparison.json')],'comparison.result.json')
(root/'comparison-registered-at.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'comparison':comparison},indent=2))
command(['report','--policy-id',policy,'--comparison-id',comparison['id']],'report-before.json')
print('Comparison registered before all four host launches.',flush=True)
running=[]
for name in names:
    out=(root/(name+'.result.json')).open('w');err=(root/(name+'.runner.log')).open('w')
    proc=subprocess.Popen([node,lyo,'task','run','--input',str(root/(name+'.registration.json')),'--trace',str(root/(name+'.jsonl')),'--host-binary','/Users/marcus.kim/.local/bin/codex','--db',db],stdout=out,stderr=err)
    running.append((name,proc,out,err))
for name,proc,out,err in running:
    code=proc.wait();out.close();err.close()
    print(json.dumps({'attempt':name,'runnerExitCode':code}),flush=True)
command(['report','--policy-id',policy,'--comparison-id',comparison['id']],'report-after.json')
print('Comparison report retained.',flush=True)
