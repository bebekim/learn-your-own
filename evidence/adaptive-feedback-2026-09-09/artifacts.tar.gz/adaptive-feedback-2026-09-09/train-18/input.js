const { format } = require('node:util');
console.log(format('%d', 18 * 18 + 1));
