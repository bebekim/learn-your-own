const { format } = require('node:util');
console.log(format('%d', 24 * 24 + 1));
