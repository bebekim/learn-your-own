import { format } from 'node:util';
console.log(format('%d', 109 * 109 + 1));
