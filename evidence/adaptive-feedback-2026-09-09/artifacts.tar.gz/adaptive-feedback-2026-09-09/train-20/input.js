const { format } = require('node:util');
console.log(format('%d', 20 * 20 + 1));
