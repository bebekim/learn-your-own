const { format } = require('node:util');
console.log(format('%d', 4 * 4 + 1));
