import { format } from 'node:util';
console.log(format('%d', 25 * 25 + 1));
