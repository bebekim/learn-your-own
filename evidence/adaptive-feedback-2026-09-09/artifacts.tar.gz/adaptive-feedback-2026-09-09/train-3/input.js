import { format } from 'node:util';
console.log(format('%d', 3 * 3 + 1));
