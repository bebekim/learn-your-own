const { format } = require('node:util');
console.log(format('%d', 6 * 6 + 1));
