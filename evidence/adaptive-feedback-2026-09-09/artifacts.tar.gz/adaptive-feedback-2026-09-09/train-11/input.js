import { format } from 'node:util';
console.log(format('%d', 11 * 11 + 1));
