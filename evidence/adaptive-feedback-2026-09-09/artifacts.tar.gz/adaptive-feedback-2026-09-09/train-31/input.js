import { format } from 'node:util';
console.log(format('%d', 31 * 31 + 1));
