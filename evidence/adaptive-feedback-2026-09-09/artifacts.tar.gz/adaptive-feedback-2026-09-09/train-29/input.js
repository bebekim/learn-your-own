import { format } from 'node:util';
console.log(format('%d', 29 * 29 + 1));
