const { format } = require('node:util');
console.log(format('%d', 0 * 0 + 1));
