const { format } = require('node:util');
console.log(format('%d', 106 * 106 + 1));
