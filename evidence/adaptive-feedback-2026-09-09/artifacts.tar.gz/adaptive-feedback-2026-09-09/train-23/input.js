import { format } from 'node:util';
console.log(format('%d', 23 * 23 + 1));
