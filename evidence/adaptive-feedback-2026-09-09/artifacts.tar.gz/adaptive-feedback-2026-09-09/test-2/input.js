const { format } = require('node:util');
console.log(format('%d', 102 * 102 + 1));
