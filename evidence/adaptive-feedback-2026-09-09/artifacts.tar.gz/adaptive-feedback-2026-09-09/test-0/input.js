const { format } = require('node:util');
console.log(format('%d', 100 * 100 + 1));
