import { format } from 'node:util';
console.log(format('%d', 15 * 15 + 1));
