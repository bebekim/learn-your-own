const { format } = require('node:util');
console.log(format('%d', 28 * 28 + 1));
