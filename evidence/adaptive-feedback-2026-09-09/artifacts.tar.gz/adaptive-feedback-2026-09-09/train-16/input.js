const { format } = require('node:util');
console.log(format('%d', 16 * 16 + 1));
