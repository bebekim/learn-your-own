import { format } from 'node:util';
console.log(format('%d', 101 * 101 + 1));
