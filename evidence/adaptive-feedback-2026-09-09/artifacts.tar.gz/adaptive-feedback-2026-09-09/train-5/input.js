import { format } from 'node:util';
console.log(format('%d', 5 * 5 + 1));
