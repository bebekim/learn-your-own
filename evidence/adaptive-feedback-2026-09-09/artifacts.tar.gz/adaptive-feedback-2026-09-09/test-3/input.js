import { format } from 'node:util';
console.log(format('%d', 103 * 103 + 1));
