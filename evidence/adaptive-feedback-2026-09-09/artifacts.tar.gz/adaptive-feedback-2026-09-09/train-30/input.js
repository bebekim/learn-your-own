const { format } = require('node:util');
console.log(format('%d', 30 * 30 + 1));
