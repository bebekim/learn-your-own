import { format } from 'node:util';
console.log(format('%d', 21 * 21 + 1));
