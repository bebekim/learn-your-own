const { format } = require('node:util');
console.log(format('%d', 22 * 22 + 1));
