const { format } = require('node:util');
console.log(format('%d', 2 * 2 + 1));
