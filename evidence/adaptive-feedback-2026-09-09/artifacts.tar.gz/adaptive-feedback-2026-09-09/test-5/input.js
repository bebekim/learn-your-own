import { format } from 'node:util';
console.log(format('%d', 105 * 105 + 1));
