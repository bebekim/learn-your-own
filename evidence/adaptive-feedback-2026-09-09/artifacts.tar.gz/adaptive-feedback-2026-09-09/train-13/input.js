import { format } from 'node:util';
console.log(format('%d', 13 * 13 + 1));
