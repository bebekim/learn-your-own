const { format } = require('node:util');
console.log(format('%d', 110 * 110 + 1));
