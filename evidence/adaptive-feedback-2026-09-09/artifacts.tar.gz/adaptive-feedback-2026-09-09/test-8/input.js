const { format } = require('node:util');
console.log(format('%d', 108 * 108 + 1));
