import { format } from 'node:util';
console.log(format('%d', 7 * 7 + 1));
