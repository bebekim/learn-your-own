import { format } from 'node:util';
console.log(format('%d', 9 * 9 + 1));
