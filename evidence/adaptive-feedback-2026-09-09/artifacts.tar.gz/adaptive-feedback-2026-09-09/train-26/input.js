const { format } = require('node:util');
console.log(format('%d', 26 * 26 + 1));
