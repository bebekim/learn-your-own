const { format } = require('node:util');
console.log(format('%d', 10 * 10 + 1));
