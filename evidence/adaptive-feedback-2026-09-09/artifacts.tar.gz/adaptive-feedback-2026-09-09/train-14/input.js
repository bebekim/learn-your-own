const { format } = require('node:util');
console.log(format('%d', 14 * 14 + 1));
