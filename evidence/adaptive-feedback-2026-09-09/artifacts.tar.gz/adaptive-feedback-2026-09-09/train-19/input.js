import { format } from 'node:util';
console.log(format('%d', 19 * 19 + 1));
