const { format } = require('node:util');
console.log(format('%d', 104 * 104 + 1));
