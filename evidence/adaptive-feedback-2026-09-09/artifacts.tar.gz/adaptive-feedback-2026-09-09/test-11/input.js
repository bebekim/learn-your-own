import { format } from 'node:util';
console.log(format('%d', 111 * 111 + 1));
