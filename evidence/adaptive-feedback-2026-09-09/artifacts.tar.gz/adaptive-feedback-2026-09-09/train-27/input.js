import { format } from 'node:util';
console.log(format('%d', 27 * 27 + 1));
