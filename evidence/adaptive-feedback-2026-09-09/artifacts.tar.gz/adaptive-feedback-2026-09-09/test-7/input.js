import { format } from 'node:util';
console.log(format('%d', 107 * 107 + 1));
