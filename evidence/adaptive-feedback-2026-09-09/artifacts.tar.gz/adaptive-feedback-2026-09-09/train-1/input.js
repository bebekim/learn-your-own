import { format } from 'node:util';
console.log(format('%d', 1 * 1 + 1));
