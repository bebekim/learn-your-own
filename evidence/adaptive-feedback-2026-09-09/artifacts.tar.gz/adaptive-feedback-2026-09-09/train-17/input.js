import { format } from 'node:util';
console.log(format('%d', 17 * 17 + 1));
