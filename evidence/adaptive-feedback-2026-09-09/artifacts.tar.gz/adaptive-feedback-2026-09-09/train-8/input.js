const { format } = require('node:util');
console.log(format('%d', 8 * 8 + 1));
