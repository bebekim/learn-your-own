const { format } = require('node:util');
console.log(format('%d', 12 * 12 + 1));
