import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).parent
runtime = sys.argv[1]
assert runtime in ('codex', 'claude')
cwd = root / 'work' / runtime
cwd.mkdir(parents=True, exist_ok=False)
(cwd / 'package.json').write_text(json.dumps({'scripts': {'test': 'node check.cjs'}}))
(cwd / 'check.cjs').write_text("console.log('canary check'); process.exit(require('node:fs').existsSync('ready') ? 0 : 1);\n")
config = root / 'canary-config.json'
config.write_text(json.dumps({'rootDir': str(root / 'work'), 'corpusPath': str(root / 'canary.sqlite'), 'adaptiveFeedback': {'mode': 'explore'}}))
env = dict(os.environ, LYO_CONFIG_FILE=str(config), ZEROSHOT_LYO_STORE_PATH=str(root / 'empty-lessons.sqlite'))
env['PATH'] = '/Users/marcus.kim/.nvm/versions/node/v24.15.0/bin:' + env['PATH']
prompt = ('Run exactly three separate shell calls, in order: rtk npm test --silent ; '
          'rtk proxy touch ready ; rtk npm test --silent . The first failure is intentional. '
          'This is a disposable hook-connection canary. Do not inspect other files or change configuration. '
          'Finish by reporting the two test outcomes.')
if runtime == 'codex':
    command = ['/Users/marcus.kim/.local/bin/codex', 'exec', '--ephemeral', '--skip-git-repo-check',
               '--sandbox', 'workspace-write', '--json', '--cd', str(cwd), prompt]
else:
    command = ['/Users/marcus.kim/.local/bin/claude', '-p', '--setting-sources', 'user', '--strict-mcp-config',
               '--tools', 'Bash', '--allowedTools', 'Bash(rtk *)', '--no-session-persistence',
               '--max-budget-usd', '0.5', '--output-format', 'stream-json', '--verbose', '--include-hook-events',
               '--system-prompt', 'Run only the three requested checks sequentially. The first failure is intentional.', prompt]
with (root / (runtime + '-host.jsonl')).open('w') as out, (root / (runtime + '-host-error.log')).open('w') as err:
    result = subprocess.run(command, cwd=cwd, env=env, stdout=out, stderr=err, stdin=subprocess.DEVNULL, timeout=180)
print(json.dumps({'runtime': runtime, 'exitCode': result.returncode, 'evidenceKind': 'instrumentation-canary', 'root': str(root)}))
sys.exit(result.returncode)
