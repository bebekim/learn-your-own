console.log('canary check'); process.exit(require('node:fs').existsSync('ready') ? 0 : 1);
