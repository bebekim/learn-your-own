console.log('native connection fixture'); process.exit(require('node:fs').existsSync('ready') ? 0 : 1);
